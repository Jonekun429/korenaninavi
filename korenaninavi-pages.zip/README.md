# コレなにナビ 個別ページ（SEO用）一式

検索エンジンに「関数・ショートカット・UIパーツ・敬語・カタカナ語」を1項目ずつ
正しく拾ってもらうための **本物の個別ページ（258ページ）** です。

## 中身
- `fn/ sc/ ui/ keigo/ kata/` … 各項目のページ（例：`fn/VLOOKUP/index.html`）
  - URLは `https://korenaninavi.jp/fn/VLOOKUP/` のようになります
  - 各ページに 専用のタイトル・説明・canonical・OGP・構造化データ（JSON-LD）入り
  - 本文の下に「アプリで開いて検索する →」ボタン（本体アプリの該当検索へ飛びます）
- `sitemap.xml` … 全259URLの一覧（トップ＋258項目）
- `robots.txt` … クローラー向け設定（sitemapの場所を記載）
- `build-pages.js` … 再生成スクリプト

## 置き方（GitHub Pages）
リポジトリの **ルート** に、`index.html` と並べて丸ごと置きます：

```
（リポジトリ直下）
├── index.html        ← 本体アプリ（別途お渡しした最新版）
├── sitemap.xml       ← この一式のもので上書き
├── robots.txt        ← この一式のもの
├── fn/  sc/  ui/  keigo/  kata/   ← この一式のフォルダ群
└── build-pages.js
```

そのまま `git add . && git commit && git push` でOKです。

## 反映後にやること（1回だけ）
Google Search Console（search.google.com/search-console）で
`korenaninavi.jp` を登録 → 「サイトマップ」に `sitemap.xml` を送信。
これで各ページがインデックスされやすくなります。

## 関数やUIパーツを増やしたとき
`index.html` を更新したあと、このフォルダに `index.html` を一時的にコピーして
`node build-pages.js` を実行すると、ページとsitemapが作り直されます。
（`node` が必要です。無ければ nodejs.org からインストール）

---

## 追加：アドセンス審査用の法務ページ・画像（今回追加）
- `about/ privacy/ disclaimer/ contact/` … このサイトについて／プライバシーポリシー／免責事項／お問い合わせ
  - Googleアドセンス審査に**必須**のページです。index.html のフッターからリンク済み。
  - ⚠ `contact/index.html` のメールアドレス `contact@korenaninavi.jp` は仮です。
    ご自身が受け取れるアドレス（Gmail等）かGoogleフォームのリンクに**必ず書き換えて**ください。
- `ogp.png` … SNSシェア時に表示されるカード画像（1200×630）
- `apple-touch-icon.png` `favicon.png` … アイコン
- これらも index.html と同じ階層（リポジトリ直下）に置いてください。

## アドセンスを入れる手順（公開後）
1. korenaninavi.jp が表示される状態にする
2. https://adsense.google.com で申し込み、サイトを登録
3. 発行された「ca-pub-〇〇」を、index.html の head 内コメント
   `<!-- <script async src="...client=ca-pub-XXXX...">`
   のコメントを外し、XXXX部分を自分のIDに置き換える
4. 審査通過後、広告ユニットのコードを ad枠（adTop/adFoot等）に差し込む
